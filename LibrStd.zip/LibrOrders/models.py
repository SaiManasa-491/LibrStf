from sqlalchemy import Column, Integer, String,ForeignKey
from database import Base

class Orders(Base):
    __tablename__ = 'LibrOrders'
    orderId = Column(Integer, primary_key=True)
    memId = Column(Integer)
    staffId = Column(Integer)
    bookId = Column(Integer)
    bookTitle = Column(String(100))
    status =  Column(String(150))
    action = Column(String(150))
    issueDate = Column(String(200))
    returnDate = Column(String(10))