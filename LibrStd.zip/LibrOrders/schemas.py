from ast import Str
from typing import Optional
from pydantic import BaseModel

class Order(BaseModel):
    memId : int
    staffId : int
    bookId : int
    bookTitle : str
    status : str
    action : str
    issueDate : str
    returnDate : str

class OrderShow(BaseModel):
    orderId : int
    memId : int
    staffId : int
    bookId : int
    bookTitle : str
    status : str
    action : str
    issueDate : str
    returnDate : str
    class Config:
        orm_mode = True