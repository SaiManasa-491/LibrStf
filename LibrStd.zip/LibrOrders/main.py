from fastapi import FastAPI
from typing import List,Union
from fastapi import FastAPI,status, HTTPException, Depends
from sqlalchemy import create_engine
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import Session
from database import Base, engine, get_session
import models , schemas
from jose import JWTError, jwt
#import hashing
#from hashing import Hash
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
Base.metadata.create_all(engine)

app = FastAPI()


origins = [
    "http://localhost",
    "http://localhost:3000"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
@app.get("/")
def getItems():
    return ['Item 1', 'Item 2', 'Item 3']


@app.get("/getOrders" , response_model = List[schemas.OrderShow], tags=['Orders'])
def read_all_orders(session: Session = Depends(get_session)): #get_current_user:schemas.User = Depends(get_current_user)
    orders_list = session.query(models.Orders).all()
    return orders_list

@app.post("/createOrder",response_model=schemas.OrderShow, status_code=status.HTTP_201_CREATED, tags=['Orders'])
def createEmployee(ord : schemas.Order , session: Session = Depends(get_session)):
    orddb = models.Orders(
        memId = ord.memId,
        staffId = ord.staffId,
        bookId = ord.bookId,
        bookTitle = ord.bookTitle,
        status = ord.status,
        action = ord.action,
        issueDate = ord.issueDate,
        returnDate = ord.returnDate)
    session.add(orddb)
    session.commit()
    session.refresh(orddb)
    return orddb


@app.get("/getOrderById/{id}", response_model=schemas.OrderShow , tags=['Orders'])
def read_order(id: int, session: Session = Depends(get_session)):
    order = session.query(models.Orders).get(id)
    # check if todo item with given id exists. If not, raise exception and return 404 not found response
    if not order:
        raise HTTPException(status_code=404, detail=f"order item with id {id} not found")

    return order

@app.put("/updateOrder/{id}" , tags=['Orders'])
def update_member(id: int, ord : schemas.Order):
    # empName: str, empDept: str, empMobile:str , empEmail:str, empPassword:str
    session = Session(bind=engine, expire_on_commit=False)
    orddb = session.query(models.Orders).get(id)
    if ord:
        orddb.memId = ord.memId
        orddb.staffId = ord.staffId
        orddb.bookId = ord.bookId
        orddb.bookTitle = ord.bookTitle
        orddb.status = ord.status
        orddb.action = ord.action
        orddb.issueDate = ord.issueDate
        orddb.returnDate = ord.returnDate
        session.commit()
    # session.close()
    if not ord:
        raise HTTPException(status_code=404, detail=f"member item with id {id} not found")
    return ord

@app.delete("/deleteOrder/{id}", status_code=status.HTTP_204_NO_CONTENT , tags=['Orders'])
def delete_order(id: int):
    session = Session(bind=engine, expire_on_commit=False)
    ord = session.query(models.Orders).get(id)
    if ord:
        session.delete(ord)
        session.commit()
        session.close()
    else:
        raise HTTPException(status_code=404, detail=f"order item with id {id} not found")

    return None