from ast import Str
from typing import Optional
from pydantic import BaseModel

class Staff(BaseModel):
    name : str
    userName : str
    password : str
    email : str
    mobileNumber : str

class StaffShow(BaseModel):
    StaffId : int
    name : str
    userName : str
    password : str
    email : str
    mobileNumber : str
    class Config:
        orm_mode = True

class Books(BaseModel):
    AccessNumber : int
    Title : str
    Author : str
    Subject : str
    Keyword : str
    Descr : str

class BooksShow(BaseModel):
    AccessNumber : int
    Title : str
    Author : str
    Subject : str
    Keyword : str
    Descr : str
    class Config:
        orm_mode = True