from sqlalchemy import Column, Integer, String,ForeignKey
from database import Base

class Staff(Base):
    __tablename__ = 'LibrStaff'
    StaffId = Column(Integer, primary_key=True)
    name = Column(String(100))
    userName =  Column(String(150))
    password = Column(String(150))
    email = Column(String(200))
    mobileNumber = Column(String(10))
       
class Books(Base):
    __tablename__ = 'Books'
    AccessNumber = Column(Integer, primary_key=True)
    Title = Column(String(100))
    Author = Column(String(200))
    Subject = Column(String(200))
    Keyword = Column(String(500))
    Descr = Column(String(2000))








