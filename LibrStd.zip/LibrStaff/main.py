from typing import List,Union
from fastapi import FastAPI,status, HTTPException, Depends
from sqlalchemy import create_engine
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import Session
import uvicorn
from database import Base, engine, get_session
import models , schemas
from jose import JWTError, jwt
#import hashing
#from hashing import Hash
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.middleware.cors import CORSMiddleware
app = FastAPI()
Base.metadata.create_all(engine)

origins = [
    "http://localhost",
    "http://localhost:3000"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def getItems():
    return ['Item 1', 'Item 2', 'Item 3']

@app.get("/getStaff" , response_model = List[schemas.StaffShow], tags=['Staff'])
def read_all_staff(session: Session = Depends(get_session)): #get_current_user:schemas.User = Depends(get_current_user)
    staff_list = session.query(models.Staff).all()
    return staff_list

@app.post("/createStaff",response_model=schemas.StaffShow, status_code=status.HTTP_201_CREATED, tags=['Staff'])
def createEmployee(stf : schemas.Staff , session: Session = Depends(get_session)):
    stfdb = models.Staff(
        name = stf.name,
        userName = stf.userName,
        password = stf.password,
        email = stf.email,
        mobileNumber = stf.mobileNumber)
    session.add(stfdb)
    session.commit()
    session.refresh(stfdb)
    return stfdb

@app.get("/getStaffById/{id}", response_model=schemas.StaffShow , tags=['Staff'])
def read_staff_byId(id: int, session: Session = Depends(get_session)):
    staff = session.query(models.Staff).get(id)
    # check if todo item with given id exists. If not, raise exception and return 404 not found response
    if not staff:
        raise HTTPException(status_code=404, detail=f"staff item with id {id} not found")

    return staff

@app.put("/updateStaff/{id}" , tags=['Staff'])
def update_staff(StaffId: int, staffs : schemas.Staff):
    # empName: str, empDept: str, empMobile:str , empEmail:str, empPassword:str
    session = Session(bind=engine, expire_on_commit=False)
    stfdb = session.query(models.Staff).get(StaffId)
    if staffs:
        stfdb.name = staffs.name
        stfdb.userName = staffs.userName
        stfdb.password = staffs.password
        stfdb.email = staffs.email
        stfdb.mobileNumber = staffs.mobileNumber
        session.commit()
    # session.close()
    if not staffs:
        raise HTTPException(status_code=404, detail=f"staff item with id {StaffId} not found")
    return staffs

@app.delete("/deleteStaff/{id}", status_code=status.HTTP_204_NO_CONTENT , tags=['Staff'])
def delete_staff(id: int):
    session = Session(bind=engine, expire_on_commit=False)
    stf = session.query(models.Staff).get(id)
    if stf:
        session.delete(stf)
        session.commit()
        session.close()
    else:
        raise HTTPException(status_code=404, detail=f"member item with id {id} not found")

    return None

@app.get("/stflogin/{userName}/{password}", tags=['Login'])
def login(userName:str , password:str , session: Session = Depends(get_session)):
    staff = session.query(models.Staff).filter((models.Staff.userName == userName)&(models.Staff.password == password)).first()
    if not staff:
        # raise HTTPException(status_code=404, detail="Invalid Credentials")
        return False
    else:
        return staff


@app.get("/getBooks" , response_model = List[schemas.BooksShow], tags=['Books'])
def read_all_books(session: Session = Depends(get_session)): #get_current_user:schemas.User = Depends(get_current_user)
    books_list = session.query(models.Books).all()
    return books_list

@app.post("/createBook",response_model=schemas.BooksShow, status_code=status.HTTP_201_CREATED, tags=['Books'])
def createBooks(book : schemas.Books , session: Session = Depends(get_session)):
    booksdb = models.Books(
        AccessNumber = book.AccessNumber,
        Title = book.Title,
        Author = book.Author,
        Subject = book.Subject,
        Keyword = book.Keyword,
        Descr = book.Descr
    )
    session.add(booksdb)
    session.commit()
    session.refresh(booksdb)
    return booksdb

@app.get("/getBookById/{id}", response_model=schemas.BooksShow , tags=['Books'])
def read_book_byId(id: int, session: Session = Depends(get_session)):
    book = session.query(models.Books).get(id)
    # check if todo item with given id exists. If not, raise exception and return 404 not found response
    if not book:
        raise HTTPException(status_code=404, detail=f"staff item with id {id} not found")
    return book

@app.put("/updateBook/{id}" , tags=['Books'])
def update_books(BookId: int, books : schemas.Books):
     # empName: str, empDept: str, empMobile:str , empEmail:str, empPassword:str
     session = Session(bind=engine, expire_on_commit=False)
     bookdb = session.query(models.Books).get(BookId)
     if books:
        bookdb.AccessNumber = books.AccessNumber
        bookdb.Title = books.Title
        bookdb.Author = books.Author
        bookdb.Subject = books.Subject
        bookdb.Keyword = books.Keyword
        bookdb.Descr = books.Descr
        session.commit()
     # session.close()
     if not books:
         raise HTTPException(status_code=404, detail=f"staff item with id {BookId} not found")
     return books

@app.delete("/deleteBooks/{id}", status_code=status.HTTP_204_NO_CONTENT , tags=['Books'])
def delete_book(id: int):
    session = Session(bind=engine, expire_on_commit=False)
    book = session.query(models.Books).get(id)
    if book:
        session.delete(book)
        session.commit()
        session.close()
    else:
        raise HTTPException(status_code=404, detail=f"book item with id {id} not found")

    return None